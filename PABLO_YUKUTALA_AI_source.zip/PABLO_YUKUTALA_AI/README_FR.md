# PABLO YUKUTALA AI — prototype Android

Application de chat Flutter au thème noir et or, sans inscription, avec :
- interface de conversation ;
- réponses hors ligne limitées ;
- connexion facultative à un serveur IA via `API_BASE_URL` ;
- aucune clé secrète d'API stockée dans l'application.

## Ce que contient ce prototype
Le projet fournit le code source et l'interface. Il ne s'agit pas encore d'un APK compilé et l'assistant ne donnera des réponses IA en ligne qu'après configuration d'un serveur compatible.

## Démarrage
1. Installer Flutter et Android Studio : https://docs.flutter.dev/get-started/install
2. Dans ce dossier, exécuter `flutter create .` si les fichiers de plateforme Android ne sont pas présents.
3. Installer les dépendances avec `flutter pub get`.
4. Lancer avec `flutter run`.
5. Pour compiler un APK : `flutter build apk --release`.

## Connecter l'IA
Le code attend un serveur HTTP à l'adresse définie dans `lib/config.dart`.
Le serveur doit accepter `POST /chat` avec `{"message":"..."}` et renvoyer `{"reply":"..."}`.
Voir `server/example_server.py` pour un exemple de structure. Ce serveur de démonstration répond localement avec des réponses simples : il n'est pas connecté à un modèle d'IA. Pour l'IA réelle, remplacez le corps de la fonction par l'appel à un fournisseur d'IA depuis le serveur et stockez la clé API dans une variable d'environnement côté serveur.

## Confidentialité et publication
Le mode sans compte signifie qu'aucune inscription n'est demandée. N'ajoutez pas de données sensibles aux conversations. Avant publication, ajoutez une politique de confidentialité, gestion des erreurs, limitation de débit et protections contre les abus.
