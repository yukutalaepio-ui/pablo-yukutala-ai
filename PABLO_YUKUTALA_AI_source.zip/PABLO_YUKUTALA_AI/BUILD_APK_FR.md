# Construire le fichier APK de PABLO YUKUTALA AI

Je ne peux pas compiler directement un APK Android dans cette session, mais voici la procédure.

## Sur un ordinateur Windows, Mac ou Linux
1. Installe Flutter et Android Studio : https://docs.flutter.dev/get-started/install
2. Décompresse `PABLO_YUKUTALA_AI_source.zip`.
3. Ouvre un terminal dans le dossier `PABLO_YUKUTALA_AI`.
4. Exécute :
   ```bash
   flutter create . --platforms=android
   flutter pub get
   flutter build apk --release
   ```
5. L'APK sera généralement créé dans :
   `build/app/outputs/flutter-apk/app-release.apk`

## À savoir
- Le projet fourni est le code source, pas un APK déjà compilé.
- L'application utilise pour le moment des réponses hors ligne limitées tant qu'une URL de serveur IA n'est pas configurée dans `lib/config.dart`.
- Pour de vraies réponses IA, il faut héberger un serveur sécurisé. Ne place jamais une clé API secrète dans le code Flutter.
- Pour installer l'APK sur un téléphone Android, transfère le fichier APK sur le téléphone et autorise l'installation depuis cette source si Android le demande. N'installe que les APK que tu as confiance.
