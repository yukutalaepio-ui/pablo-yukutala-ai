import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

void main() => runApp(const PabloAiApp());

const gold = Color(0xFFD4AF37);
const bg = Color(0xFF0B0B0D);
const panel = Color(0xFF171719);

class PabloAiApp extends StatelessWidget {
  const PabloAiApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'PABLO YUKUTALA AI',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: gold, centerTitle: true),
      useMaterial3: true,
    ),
    home: const ChatPage(),
  );
}

class ChatMessage {
  final String text;
  final bool fromUser;
  ChatMessage(this.text, this.fromUser);
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final scrollController = ScrollController();
  final messages = <ChatMessage>[
    ChatMessage("Bienvenue ! Je suis PABLO YUKUTALA AI 👑\nComment puis-je t'aider aujourd'hui ?", false),
  ];
  bool busy = false;

  String offlineReply(String input) {
    final s = input.toLowerCase();
    if (s.contains('bonjour') || s.contains('salut') || s.contains('mbote')) {
      return "Bonjour et bienvenue chez PABLO YUKUTALA AI 👑 Que puis-je faire pour toi ?";
    }
    if (s.contains('qui es-tu') || s.contains('ton nom')) {
      return "Je suis PABLO YUKUTALA AI, un assistant conversationnel créé comme projet par PABLO YUKUTALA.";
    }
    if (s.contains('motivation') || s.contains('courage')) {
      return "Garde confiance en toi. Les grandes réussites commencent par de petites actions répétées avec discipline. Avance chaque jour, même lentement. 💪";
    }
    if (s.contains('merci')) return "Avec plaisir ! Je suis là pour t'aider. 👑";
    if (s.contains('lingala')) {
      return "Mbote! Nazali PABLO YUKUTALA AI. Nakoki kosalisa yo na makambo ndenge na ndenge. (Mode hors ligne : réponses limitées.)";
    }
    return "Je suis actuellement en mode hors ligne : mes réponses sont limitées. Connecte un serveur d'intelligence artificielle pour obtenir des réponses plus complètes.";
  }

  Future<String> getReply(String text) async {
    final base = AppConfig.apiBaseUrl.trim();
    if (base.isEmpty) return offlineReply(text);
    try {
      final response = await http.post(
        Uri.parse('$base/chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'message': text}),
      ).timeout(const Duration(seconds: 30));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        if (data['reply'] is String) return data['reply'] as String;
      }
      return 'Le serveur ne peut pas répondre pour le moment. Réessaie plus tard.';
    } catch (_) {
      return 'Connexion impossible. Vérifie Internet ou réessaie plus tard.';
    }
  }

  Future<void> send() async {
    final text = controller.text.trim();
    if (text.isEmpty || busy) return;
    controller.clear();
    setState(() {
      messages.add(ChatMessage(text, true));
      busy = true;
    });
    await Future.delayed(const Duration(milliseconds: 100));
    if (scrollController.hasClients) {
      scrollController.animateTo(scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
    final reply = await getReply(text);
    if (!mounted) return;
    setState(() {
      messages.add(ChatMessage(reply, false));
      busy = false;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scrollController.hasClients) scrollController.animateTo(
        scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  @override
  void dispose() {
    controller.dispose();
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Column(children: [
        Text('👑 PABLO YUKUTALA AI', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.0, fontSize: 17)),
        Text('ASSISTANT INTELLIGENT', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 2)),
      ]),
    ),
    body: Column(children: [
      Container(
        width: double.infinity, margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF28200B), Color(0xFF171719)]),
          border: Border.all(color: gold.withOpacity(.55)),
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Row(children: [
          Icon(Icons.auto_awesome, color: gold, size: 30),
          SizedBox(width: 12),
          Expanded(child: Text('Votre assistant personnel\\nFrançais • Lingala • English', style: TextStyle(fontWeight: FontWeight.w600))),
        ]),
      ),
      Expanded(child: ListView.builder(
        controller: scrollController, padding: const EdgeInsets.all(16),
        itemCount: messages.length + (busy ? 1 : 0),
        itemBuilder: (context, index) {
          if (busy && index == messages.length) {
            return const Align(alignment: Alignment.centerLeft, child: Padding(
              padding: EdgeInsets.all(12), child: Text('PABLO AI écrit…', style: TextStyle(color: gold))));
          }
          final m = messages[index];
          return Align(
            alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .82),
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: m.fromUser ? const Color(0xFF3A2E0C) : panel,
                border: Border.all(color: m.fromUser ? gold.withOpacity(.7) : Colors.white12),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(m.text, style: const TextStyle(fontSize: 15, height: 1.4)),
            ),
          );
        },
      )),
      SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(children: [
          Expanded(child: TextField(
            controller: controller, minLines: 1, maxLines: 5,
            onSubmitted: (_) => send(),
            decoration: InputDecoration(
              hintText: 'Écris ton message…',
              filled: true, fillColor: panel,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            ),
          )),
          const SizedBox(width: 8),
          IconButton.filled(
            onPressed: busy ? null : send,
            icon: const Icon(Icons.send_rounded),
            style: IconButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black),
          ),
        ]),
      )),
    ]),
  );
}
