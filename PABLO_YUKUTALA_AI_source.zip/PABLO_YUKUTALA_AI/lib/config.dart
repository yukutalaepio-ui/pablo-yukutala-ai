class AppConfig {
  // Adresse du serveur Render de PABLO YUKUTALA AI.
  static const String apiBaseUrl = 'https://pablo-yukutala-ai.onrender.com';
}
