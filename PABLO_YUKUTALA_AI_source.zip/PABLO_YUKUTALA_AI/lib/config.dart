class AppConfig {
  // Remplacez par l'URL HTTPS de votre serveur IA après déploiement.
  // Laisser vide pour utiliser uniquement les réponses hors ligne.
  static const String apiBaseUrl = '';
}
