"""Exemple minimal de serveur pour tester l'interface.
Ce serveur renvoie des réponses simples et N'EST PAS une IA réelle.
Lancez avec : python example_server.py
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/chat":
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", "0"))
        data = json.loads(self.rfile.read(length) or b"{}")
        message = str(data.get("message", "")).strip()
        reply = ("Bonjour ! Ceci est le serveur de démonstration de PABLO YUKUTALA AI. "
                 "Pour obtenir de vraies réponses IA, connectez ici un fournisseur d'IA côté serveur.")
        if not message:
            reply = "Écris un message pour commencer."
        body = json.dumps({"reply": reply}, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        print(format % args)

if __name__ == "__main__":
    print("Serveur de démonstration : http://127.0.0.1:8080")
    HTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
